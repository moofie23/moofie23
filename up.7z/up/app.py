from flask import Flask, render_template, request, redirect, session, url_for, flash
import sqlite3
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'your_secret_key_123'

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        login = request.form['login']
        password = request.form['password']
        
        conn = sqlite3.connect('test1.db')
        c = conn.cursor()
        c.execute("SELECT id, role, name FROM users WHERE login=? AND password=? AND active=1", (login, password))
        user = c.fetchone()
        conn.close()
        
        if user:
            session['user_id'] = user[0]
            session['role'] = user[1]
            session['user_name'] = user[2]
            
            if user[1] == 'admin':
                return redirect(url_for('admin_dashboard'))
            elif user[1] == 'waiter':
                return redirect(url_for('waiter_dashboard'))
            elif user[1] == 'cook':
                return redirect(url_for('cook_dashboard'))
    
    return render_template('login.html')

@app.route('/admin')
def admin_dashboard():
    if session.get('role') != 'admin':
        return redirect('/')
    
    conn = sqlite3.connect('test1.db')
    c = conn.cursor()
    
    c.execute("SELECT id, name, role, active FROM users")
    users = c.fetchall()
    
    c.execute("SELECT s.id, s.date, GROUP_CONCAT(u.name, ', ') FROM shifts s LEFT JOIN shift_assignments sa ON s.id = sa.shift_id LEFT JOIN users u ON sa.user_id = u.id GROUP BY s.id")
    shifts = c.fetchall()
    
    c.execute("SELECT o.id, o.status, o.table_number, u.name FROM orders o JOIN users u ON o.waiter_id = u.id")
    orders = c.fetchall()
    
    conn.close()
    
    return render_template('admin_dashboard.html', users=users, shifts=shifts, orders=orders)

@app.route('/waiter')
def waiter_dashboard():
    if session.get('role') != 'waiter':
        return redirect('/')
    
    conn = sqlite3.connect('test1.db')
    c = conn.cursor()
    
    c.execute("SELECT id, status, table_number FROM orders WHERE waiter_id = ?", (session['user_id'],))
    orders = c.fetchall()
    
    c.execute("SELECT id, name, price FROM dishes")
    dishes = c.fetchall()
    
    conn.close()
    
    return render_template('waiter_dashboard.html', orders=orders, dishes=dishes)

@app.route('/cook')
def cook_dashboard():
    if session.get('role') != 'cook':
        return redirect('/')
    
    try:
        conn = sqlite3.connect('test1.db')
        c = conn.cursor()
        
        c.execute("""
            SELECT o.id, o.table_number, o.status 
            FROM orders o 
            WHERE o.status IN ('принят', 'готовится')
            ORDER BY 
                CASE o.status 
                    WHEN 'принят' THEN 1 
                    WHEN 'готовится' THEN 2 
                    ELSE 3 
                END,
                o.id
        """)
        orders = c.fetchall()
        conn.close()
        
        return render_template('cook_dashboard.html', orders=orders)
    
    except Exception as e:
        flash(f'Ошибка при загрузке заказов: {str(e)}', 'error')
        return render_template('cook_dashboard.html', orders=[])

@app.route('/admin/add_user', methods=['POST'])
def add_user():
    if session.get('role') != 'admin':
        return redirect('/')
    
    name = request.form['name']
    role = request.form['role']
    login = request.form['login']
    password = request.form['password']
    
    conn = sqlite3.connect('test1.db')
    c = conn.cursor()
    c.execute("INSERT INTO users (name, role, login, password) VALUES (?, ?, ?, ?)", 
              (name, role, login, password))
    conn.commit()
    conn.close()
    
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/deactivate_user/<int:user_id>')
def deactivate_user(user_id):
    if session.get('role') != 'admin':
        return redirect('/')
    
    conn = sqlite3.connect('test1.db')
    c = conn.cursor()
    c.execute("UPDATE users SET active = 0 WHERE id = ?", (user_id,))
    conn.commit()
    conn.close()
    
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/add_shift', methods=['POST'])
def add_shift():
    if session.get('role') != 'admin':
        return redirect('/')
    
    date = request.form['date']
    waiter_ids = request.form.getlist('waiters')
    cook_ids = request.form.getlist('cooks')
    
    conn = sqlite3.connect('test1.db')
    c = conn.cursor()
    
    c.execute("INSERT INTO shifts (date) VALUES (?)", (date,))
    shift_id = c.lastrowid
    
    for waiter_id in waiter_ids:
        c.execute("INSERT INTO shift_assignments (shift_id, user_id) VALUES (?, ?)", 
                 (shift_id, waiter_id))

    for cook_id in cook_ids:
        c.execute("INSERT INTO shift_assignments (shift_id, user_id) VALUES (?, ?)", 
                 (shift_id, cook_id))
    
    conn.commit()
    conn.close()
    
    return redirect(url_for('admin_dashboard'))

@app.route('/waiter/create_order', methods=['POST'])
def create_order():
    if session.get('role') != 'waiter':
        return redirect('/')
    
    table_number = request.form['table_number']
    guests_count = request.form['guests_count']
    dish_ids = request.form.getlist('dishes')
    quantities = request.form.getlist('quantities')
    
    conn = sqlite3.connect('test1.db')
    c = conn.cursor()
    
    try:
        c.execute("""
            INSERT INTO orders (status, waiter_id, table_number, guests_count) 
            VALUES (?, ?, ?, ?)
        """, ('принят', session['user_id'], table_number, guests_count))
        order_id = c.lastrowid
        
        for dish_id, quantity in zip(dish_ids, quantities):
            if int(quantity) > 0:
                c.execute("INSERT INTO order_items (order_id, dish_id, quantity) VALUES (?, ?, ?)", 
                         (order_id, dish_id, quantity))
        
        conn.commit()
        flash('Заказ успешно создан', 'success')
    except Exception as e:
        conn.rollback()
        flash(f'Ошибка при создании заказа: {str(e)}', 'error')
    finally:
        conn.close()
    
    return redirect(url_for('waiter_dashboard'))

@app.route('/waiter/update_order_status/<int:order_id>/<status>')
def update_order_status(order_id, status):
    if session.get('role') not in ['waiter', 'cook']:
        return redirect('/')
    
    conn = sqlite3.connect('test1.db')
    c = conn.cursor()
    c.execute("UPDATE orders SET status = ? WHERE id = ?", (status, order_id))
    conn.commit()
    conn.close()
    
    if session.get('role') == 'waiter':
        return redirect(url_for('waiter_dashboard'))
    else:
        return redirect(url_for('cook_dashboard'))

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')

if __name__ == '__main__':
    app.run(debug=True)