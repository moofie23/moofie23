import sqlite3

conn = sqlite3.connect('test1.db')
c = conn.cursor()

c.execute("""CREATE TABLE IF NOT EXISTS users (
     id integer PRIMARY KEY,
     name text NOT NULL,
     role text,
     login text NOT NULL,
     password text NOT NULL,
     active boolean DEFAULT 1
)""")

c.execute("""CREATE TABLE IF NOT EXISTS shifts (
     id integer PRIMARY KEY,
     date text
)""")

c.execute("""CREATE TABLE IF NOT EXISTS shift_assignments (
     id integer PRIMARY KEY,
     shift_id integer REFERENCES shifts(id),
     user_id integer REFERENCES users(id)
)""")

c.execute("""CREATE TABLE IF NOT EXISTS orders (
     id integer PRIMARY KEY,
     status text,
     waiter_id integer REFERENCES users(id),
     shift_id integer REFERENCES shifts(id),
     table_number integer,
     guests_count integer,
     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)""")

c.execute("""CREATE TABLE IF NOT EXISTS dishes (
     id integer PRIMARY KEY,
     name text,
     price real
)""")

c.execute("""CREATE TABLE IF NOT EXISTS order_items (
     id integer PRIMARY KEY,
     order_id integer REFERENCES orders(id),
     dish_id integer REFERENCES dishes(id),
     quantity integer
)""")

c.execute("INSERT OR IGNORE INTO users VALUES (1, 'Андрей', 'admin', 'admin', 'admin123', 1)")
c.execute("INSERT OR IGNORE INTO users VALUES (2, 'Влад', 'waiter', 'waiter', 'waiter123', 1)")
c.execute("INSERT OR IGNORE INTO users VALUES (3, 'Марат', 'cook', 'cook', 'cook123', 1)")

c.execute("INSERT OR IGNORE INTO dishes VALUES (1, 'Суп', 5.99)")
c.execute("INSERT OR IGNORE INTO dishes VALUES (2, 'Салат', 4.50)")
c.execute("INSERT OR IGNORE INTO dishes VALUES (3, 'Стейк', 12.99)")

conn.commit()
conn.close()