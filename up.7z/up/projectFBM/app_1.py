import os
from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_sqlalchemy import SQLAlchemy
from models import db, UserAccount, Category, Product, OrderRecord, TransactionRecord
from flask_login import LoginManager, login_user, login_required, logout_user, current_user
from werkzeug.security import check_password_hash, generate_password_hash

app = Flask(__name__)

# Путь к базе данных (она находится в папке instance)
base_dir = os.path.abspath(os.path.dirname(__file__))
db_path = os.path.join(base_dir, 'instance', 'fbm.db')  # путь к файлу базы данных
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + db_path
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'hfn345987w0fseo87ho8743&OERGMJQ#O&89ooifehrjw97dc4')

# Инициализация базы данных
db.init_app(app)

# Инициализация Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'auth_page'

@login_manager.user_loader
def load_user(user_id):
    return UserAccount.query.get(int(user_id))

# Главная страница
@app.route('/')
def home_page():
    return render_template('home.html', title="Главная")

@app.route('/buy', methods=['GET'])
def buy_page():
    page = request.args.get('page', 1, type=int)  # Получаем номер страницы из параметров запроса, по умолчанию 1
    selected_category = request.args.get('category', None)  # Получаем выбранную категорию, если она есть
    
    # Фильтруем продукты по выбранной категории, если она существует
    if selected_category:
        products_query = Product.query.filter_by(category_id=selected_category, is_active=True)
    else:
        products_query = Product.query.filter_by(is_active=True)

    # Используем paginate с правильным количеством аргументов
    products = products_query.paginate(page=page, per_page=15, error_out=False)

    categories = Category.query.all()  # Получаем все категории для фильтра
    return render_template('buy.html', 
                           products = products.items, 
                           categories = categories, 
                           page = page, 
                           pages = products.pages, 
                           selected_category = selected_category)



    
@app.route('/sell', methods=['GET', 'POST'])
@login_required
def sell_page():
    if request.method == 'POST':
        category_id = request.form.get('category_id')
        if category_id is None or category_id == '':
            flash('Выберите категорию товара', 'error')
            return redirect(url_for('sell_page'))
        
        product_name = request.form.get('product_name')
        product_description = request.form.get('product_description', '')
        price = request.form.get('price', type=float)
        quantity = request.form.get('quantity', type=int)

        # Проверка на заполнение обязательных полей
        if not product_name or price is None or quantity is None:
            flash('Пожалуйста, заполните все обязательные поля', 'error')
            return redirect(url_for('sell_page'))

        # Создание нового продукта
        new_product = Product(
            seller_account_id=current_user.user_account_id,
            category_id=category_id,
            product_name=product_name,
            product_description=product_description,
            price=price,
            quantity=quantity
        )
        db.session.add(new_product)
        db.session.commit()

        flash('Продукт успешно добавлен!', 'success')
        return redirect(url_for('buy_page'))

    categories = Category.query.all()  # Получаем все категории для выпадающего списка
    return render_template('sell.html', categories=categories)



# Страница с изображением
@app.route('/image')
def image_page():
    return render_template('image.html', title="Страница с изображением")

# Страница с текстом
@app.route('/text')
def text_page():
    return render_template('text.html', title="Страница с текстом")

@app.route('/auth', methods=['GET', 'POST'])
def auth_page():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        remember = 'remember' in request.form  # Проверка, был ли установлен флажок "Запомнить меня"

        # Найти пользователя по имени
        user = UserAccount.query.filter_by(username=username).first()

        if user and check_password_hash(user.password, password):
            # Авторизуем пользователя и активируем сессию
            login_user(user, remember=remember)
            return redirect(url_for('profile_page'))  # Перенаправление в профиль после входа
        else:
            flash("Неверный логин или пароль", "error")

    return render_template('auth.html', title="Страница авторизации")

# Страница регистрации нового пользователя
@app.route('/register', methods=['GET', 'POST'])
def reg_page():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']

        # Проверка на существование пользователя с таким же email
        existing_user_by_email = UserAccount.query.filter_by(email=email).first()

        if existing_user_by_email:
            flash('Пользователь с таким email уже существует!', 'error')
            return redirect(url_for('reg_page'))

        # Хеширование пароля перед сохранением
        hashed_password = generate_password_hash(password, method='pbkdf2:sha256')

        # Создание нового пользователя
        new_user = UserAccount(username=username, email=email, password=hashed_password)
        db.session.add(new_user)
        db.session.commit()

        flash('Регистрация прошла успешно!', 'success')
        login_user(new_user)
        return redirect(url_for('profile_page'))

    return render_template('register.html')

# Пополнение баланса
@app.route('/top-up', methods=['POST'])
@login_required
def top_up_balance():
    amount = request.form.get('amount', type=float)
    if amount and amount > 0:
        current_user.balance += amount
        db.session.commit()
        flash(f"Баланс успешно пополнен на {amount} руб.")
    else:
        flash("Введите корректную сумму.")
    return redirect(url_for('profile_page'))


# Страница профиля пользователя
@app.route('/profile')
@login_required
def profile_page():
    orders = db.session.query(OrderRecord, Product).join(Product, OrderRecord.product_id == Product.product_id).filter(OrderRecord.buyer_account_id == current_user.user_account_id).all()
    return render_template('profile.html', user=current_user, orders=orders)

# Страница профиля другого пользователя(продавца)
@app.route('/seller_profile/<int:user_id>')
def profile(user_id):
    user_account = UserAccount.query.get(user_id)
    if user_account:
        orders = OrderRecord.query.filter_by(buyer_account_id=user_account.user_account_id).all()
        return render_template('seller_profile.html', user_account=user_account, orders=orders)
    else:
        return "Пользователь не наден", 404


# Страница для просмотра всех пользователей
@app.route('/user')
def users_page():
    users_list = UserAccount.query.all()
    return render_template('user.html', users=users_list)

# Выход из аккаунта
@app.route('/logout', methods=['POST'])
@login_required
def logout():
    logout_user()
    return redirect(url_for('auth_page'))

@app.route('/purchase/<int:product_id>', methods=['GET', 'POST'])
@login_required
def purchase_page(product_id):
    product = Product.query.get_or_404(product_id)

    if request.method == 'POST':
        quantity = request.form.get('quantity', type=int)
        if quantity > product.quantity:
            flash('Недостаточно товара на складе', 'error')
            return redirect(url_for('purchase_page', product_id=product_id))

        total_price = product.price * quantity
        if current_user.balance < total_price:
            flash('Недостаточно средств на балансе', 'error')
            return redirect(url_for('purchase_page', product_id=product_id))

        # Обновление балансов и количества товара
        current_user.balance -= total_price
        product.seller_account.balance += total_price
        product.quantity -= quantity

        # Удаление товара, если его количество стало нулевым
        if product.quantity == 0:
            db.session.delete(product)

        # Создание записи о заказе
        order_record = OrderRecord(
            buyer_account_id=current_user.user_account_id,
            product_id=product.product_id,
            quantity=quantity,
            total_amount=total_price,
            order_status='Completed'
        )
        db.session.add(order_record)
        db.session.commit()

        # Запись транзакции
        record_transaction(order_record.order_record_id, current_user.user_account_id, total_price, 'Purchase')

        flash('Покупка успешно совершена', 'success')
        return redirect(url_for('buy_page'))

    return render_template('purchase.html', product=product)

@app.route('/orders', methods=['GET'])
@login_required
def orders_page():
    orders = OrderRecord.query.filter_by(buyer_account_id=current_user.user_account_id).all()
    return render_template('orders.html', orders=orders)

@app.route('/rate_user/<int:user_id>/upvote', methods=['POST'])
@login_required
def upvote_user(user_id):
    user_account = UserAccount.query.get(user_id)
    if user_account:
        user_account.rating += 1
        db.session.commit()
        flash('Рейтинг увеличен!', 'success')
        # Сохраняем информацию о голосовании в сессии
        session[f'voted_{user_id}'] = True
    else:
        flash('Пользователь не найден', 'error')
    return redirect(url_for('profile', user_id=user_id))

@app.route('/rate_user/<int:user_id>/downvote', methods=['POST'])
@login_required
def downvote_user(user_id):
    user_account = UserAccount.query.get(user_id)
    if user_account:
        user_account.rating -= 1
        db.session.commit()
        flash('Рейтинг уменьшен!', 'success')
        # Сохраняем информацию о голосовании в сессии
        session[f'voted_{user_id}'] = True
    else:
        flash('Пользователь не найден', 'error')
    return redirect(url_for('profile', user_id=user_id))

@app.route('/transactions', methods=['GET'])
@login_required
def transactions_page():
    transactions = TransactionRecord.query.filter_by(user_account_id=current_user.user_account_id).all()
    return render_template('transactions.html', transactions=transactions)

#Код для записи транзакции
def record_transaction(order_id, user_id, amount, transaction_type):
    transaction = TransactionRecord(
        order_record_id=order_id,
        user_account_id=user_id,
        amount=amount,
        transaction_type=transaction_type,
        transaction_status='Completed'
    )
    db.session.add(transaction)
    db.session.commit()

if __name__ == '__main__':
    app.run(debug=True)