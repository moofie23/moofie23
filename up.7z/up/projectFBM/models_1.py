from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin

# Инициализация базы данных
db = SQLAlchemy()

class UserAccount(db.Model, UserMixin):
    __tablename__ = 'user_account'
    user_account_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    avatar = db.Column(db.LargeBinary)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)
    registration_date = db.Column(db.DateTime, default=db.func.current_timestamp())
    rating = db.Column(db.Float, default=0.0)
    balance = db.Column(db.Float, default=0.00)
    is_active = db.Column(db.Boolean, default=True)

    def check_password(self, password):
        return check_password_hash(self.password, password)
    # Метод, который требуется для работы Flask-Login
    def get_id(self):
        return str(self.user_account_id)


class Category(db.Model):
    __tablename__ = 'category'
    category_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    category_name = db.Column(db.String(100), unique=True, nullable=False)
    category_description = db.Column(db.String(255))

class Product(db.Model):
    __tablename__ = 'product'
    product_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    seller_account_id = db.Column(db.Integer, db.ForeignKey('user_account.user_account_id'))
    category_id = db.Column(db.Integer, db.ForeignKey('category.category_id'))
    product_name = db.Column(db.String(100), nullable=False)
    product_description = db.Column(db.String(255))
    price = db.Column(db.Float, nullable=False)
    quantity = db.Column(db.Integer, default=1)
    created_at = db.Column(db.DateTime, default=db.func.current_timestamp())
    is_active = db.Column(db.Boolean, default=True)
    category = db.relationship('Category', backref='products')
    seller_account = db.relationship('UserAccount', backref='products')
    
class OrderRecord(db.Model):
    __tablename__ = 'order_record'
    order_record_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    buyer_account_id = db.Column(db.Integer, db.ForeignKey('user_account.user_account_id'))
    product_id = db.Column(db.Integer, db.ForeignKey('product.product_id'))
    order_date = db.Column(db.DateTime, default=db.func.current_timestamp())
    quantity = db.Column(db.Integer, default=1)
    total_amount = db.Column(db.Float, nullable=False)
    order_status = db.Column(db.String(50), default='Pending')

class TransactionRecord(db.Model):
    __tablename__ = 'transaction_record'
    transaction_record_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    order_record_id = db.Column(db.Integer, db.ForeignKey('order_record.order_record_id'))
    user_account_id = db.Column(db.Integer, db.ForeignKey('user_account.user_account_id'))
    amount = db.Column(db.Float, nullable=False)
    transaction_type = db.Column(db.String(50), nullable=False)
    transaction_date = db.Column(db.DateTime, default=db.func.current_timestamp())
    transaction_status = db.Column(db.String(50), default='Completed')
