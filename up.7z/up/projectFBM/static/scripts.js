document.addEventListener('DOMContentLoaded', function (){
    $('#purchaseModal').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget);
        
        // Получаем данные из кнопки, которая открыла модальное окно
        var productName = button.data('product-name');
        var productDescription = button.data('product-description');
        var productQuantity = button.data('product-quantity'); // Количество товара
        var productPrice = button.data('product-price');       // Цена за единицу
    
        var modal = $(this);
    
        // Заполняем модальное окно данными о продукте
        modal.find('#modal-product-name').text(productName);
        modal.find('#modal-product-description').text(productDescription);
        modal.find('#modal-product-quantity').text(productQuantity);
        modal.find('#modal-product-price').text(productPrice);
    
        // Устанавливаем начальное значение и максимальное количество для поля ввода
        var quantityInput = modal.find('#purchase-quantity');
        quantityInput.val(1); // Начальное значение
        quantityInput.attr('max', productQuantity); // Устанавливаем максимальное значение
    
        // Рассчитываем начальную итоговую цену
        var totalPrice = productPrice;
        modal.find('#modal-total-price').text(totalPrice);
    
        // Обновляем итоговую цену при изменении количества
        quantityInput.on('input', function () {
            var quantity = parseInt($(this).val()) || 1; // Получаем выбранное количество
            if (quantity > productQuantity) {
                quantity = productQuantity;
                $(this).val(quantity); // Ограничиваем значение максимальным количеством
            }
            var newTotalPrice = productPrice * quantity;
            modal.find('#modal-total-price').text(newTotalPrice); // Обновляем итоговую цену
            modal.find('#quantity').on('input', function () {
                var quantity = $(this).val();
                var totalPrice = productPrice * quantity;
                modal.find('#total-price').text(totalPrice);
            
                // Устанавливаем значение для скрытого поля
                modal.find('#quantity-input').val(quantity);
            });
            
        });
    });
});
