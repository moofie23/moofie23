from flask import Flask, render_template, request, redirect
#from models import Users
from flask_sqlalchemy import SQLAlchemy
from flask_login import current_user, login_user


app = Flask(__name__)

app.config ['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///my_db.db'
db = SQLAlchemy(app)

class User(db.Model):
   id = db.Column('user_id', db.Integer, primary_key = True)
   name = db.Column(db.String(100))
   password = db.Column(db.String(50))

#@app.route('/')
@app.route('/form', methods=['GET', 'POST'])
def login():
   
    if request.method == 'POST':
        name = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(name = name).first()
        # проверка логина и пароля
        if user is not None:
            return 'Зашли в симтему'
    return render_template('form.html')    


if __name__ == '__main__':
    app.run()
