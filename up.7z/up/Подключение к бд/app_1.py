from flask_sqlalchemy import SQLAlchemy
from flask import Flask

app = Flask (__name__)
#Строка подключения
app.config ['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///students.db'
db = SQLAlchemy(app)
# Класс таблицы
class students(db.Model):
   id = db.Column('student_id', db.Integer, primary_key = True)
   name = db.Column(db.String(100))
   city = db.Column(db.String(50)) 

   def __init__(self, name, city):
        self.name = name
        self.city = city


#db.create_all() #Раскоментировать если надо создать базу данных        
# Открытие контекста для операций        
with app.app_context():
    student = students('Саша', 'Cehuen')
    db.session.add(student)
    db.session.commit()
    #db.create_all()

